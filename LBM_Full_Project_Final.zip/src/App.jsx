export default function App() {
  return (
    <div style={{ fontFamily: 'sans-serif', textAlign: 'center', marginTop: '5rem' }}>
      <h1>LBM Financial Group</h1>
      <p>Smarter Finance. Stronger Futures.</p>
    </div>
  )
}
